# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import requests

city = "Moscow,RU"
appid = "f9659ce4b0d4a1f6e2035c56f3d335ff"

res=requests.get("http://api.openweathermap.org/data/2.5/forecast",
    params={'q':city,'units':'metric','lang':'ru','APPID':appid})
data=res.json()

#print("Город:", city)
#print("Погодные условия:", data['weather'][0]['description'])
#print("Температура:", data['main']['temp'])
#print("Минимальная температура:", data['main']['temp_min'])
#print("Максимальная температура:", data['main']['temp_max'])
#print("Скорость ветра:", data['wind']['speed'])
#print("Видимость:", data['visibility'])

print("Прогноз погоды на неделю:")
for i in data['list']:
    print("Дата<", i['dt_txt'],">\r\nТемпература:",'{0:+3.0f}'.format(i['main']['temp']), "\r\nПогодные условия:",
          i['weather'][0]['description'], "\r\nСкорость ветра:", i['wind']['speed'],
           "\r\nВидимость:", i['visibility'])
    print("========================")